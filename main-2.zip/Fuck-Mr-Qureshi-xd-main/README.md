# Fuck-Mr-Qureshi-xd

git clone https://github.com/ferdousvau1/Fuck-Mr-Qureshi-xd
